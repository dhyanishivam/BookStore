package com.bookStore.BookStore1.beans;



import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "book")
@SequenceGenerator(name = "bookseq", initialValue = 1, allocationSize = 1000)
public class Book {
	
	@Id
	@Column(name = "bookId")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bookseq")
	private int bookId;
	
	
	@OneToOne(cascade = CascadeType.MERGE)
	@NotNull
	@JoinColumn(name = "categoryId")
	private Category category;
	
	
	@Column(name = "title")
	@NotNull
	private String title;
	
	
	@Column(name = "author")
	@NotNull
	private String author;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "ISBNnumber")
	@NotNull
	private String ISBNnumber;
	
	@Column(name = "thumbnailImage")
	private String thumbnailImage;
	
	@Column(name = "price")
	private double price;
	
	@Column(name = "publishedDate")
	private Date publishedDate;
	
	@Column(name = "rating")
	private double rating;
	
	@Column(name = "copiesSold")
	private int copiesSold;
	
	
	/*
	 * Getters and Setters
	 */
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public int getCopiesSold() {
		return copiesSold;
	}

	public void setCopiesSold(int copiesSold) {
		this.copiesSold = copiesSold;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getISBNnumber() {
		return ISBNnumber;
	}

	public void setISBNnumber(String iSBNnumber) {
		ISBNnumber = iSBNnumber;
	}

	public String getThumbnailImage() {
		return thumbnailImage;
	}

	public void setThumbnailImage(String thumbnailImage) {
		this.thumbnailImage = thumbnailImage;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	
}
