package com.bookStore.BookStore1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookStore.BookStore1.beans.Book;

public interface ListBooksRepo extends JpaRepository<Book, Integer> {

}
