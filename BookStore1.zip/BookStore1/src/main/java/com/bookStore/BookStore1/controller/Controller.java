package com.bookStore.BookStore1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.CategoryIdAlreadyExistsException;
import com.bookStore.BookStore1.service.CategoryMgmt;

@RestController
public class Controller {
	
	@Autowired
	CategoryMgmt categoryMgmt;
	
	@RequestMapping(value="/createCategory",method=RequestMethod.PUT)
	public Category createCategory(@RequestBody Category category) throws CategoryIdAlreadyExistsException
	{
		
		return categoryMgmt.createCategory(category);
	}
	
	@RequestMapping(value="/findAllCategory",method=RequestMethod.GET)
	public List<Category> findAllCategory()
	{
		return categoryMgmt.findAllCategory();
	}
	
	@RequestMapping(value="/deleteCategory/{categoryId}",method=RequestMethod.DELETE)
	public Category deleteCategory(@PathVariable int categoryId) throws CategoryDoesNotExistsException
	{
		return categoryMgmt.deletecategory(categoryId);
	}
	
	@RequestMapping(value="/editCategory",method=RequestMethod.PUT)
	public Category editCategory(@RequestBody Category category) throws CategoryDoesNotExistsException
	{
		return categoryMgmt.editCategory(category);
	}	
	
	
}
