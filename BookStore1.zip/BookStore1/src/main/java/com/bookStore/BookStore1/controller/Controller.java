package com.bookStore.BookStore1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bookStore.BookStore1.beans.Book;
import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.CategoryIdAlreadyExistsException;
import com.bookStore.BookStore1.exceptions.NoBooksFoundException;
import com.bookStore.BookStore1.service.CategoryMgmt;
import com.bookStore.BookStore1.service.ListBooks;

@RestController
public class Controller {
	
	@Autowired
	CategoryMgmt categoryMgmt;
	
	@RequestMapping(value="/createCategory",method=RequestMethod.PUT)
	public Category createCategory(@RequestBody Category category) throws CategoryIdAlreadyExistsException
	{
		
		return categoryMgmt.createCategory(category);
	}
	
	@RequestMapping(value="/findAllCategory",method=RequestMethod.GET)
	public List<Category> findAllCategory()
	{
		return categoryMgmt.findAllCategory();
	}
	
	@RequestMapping(value="/deleteCategory/{categoryId}",method=RequestMethod.DELETE)
	public Category deleteCategory(@PathVariable int categoryId) throws CategoryDoesNotExistsException
	{
		return categoryMgmt.deletecategory(categoryId);
	}
	
	@RequestMapping(value="/editCategory",method=RequestMethod.PUT)
	public Category editCategory(@RequestBody Category category) throws CategoryDoesNotExistsException
	{
		return categoryMgmt.editCategory(category);
	}	
	
	@Autowired
	ListBooks listBooks;
	
	@RequestMapping(value="/categoryBooks/{category}",method=RequestMethod.GET)
	public List<Book> categoryBooks(@PathVariable String category) throws CategoryDoesNotExistsException
	{
		return listBooks.categoryBooks(category);
	}
	
	@RequestMapping(value="/showAllBooks",method=RequestMethod.GET)
	public List<Book> showAllBooks() throws NoBooksFoundException
	{
		return listBooks.showAllBooks();
	}
	
	@RequestMapping(value="/recentBooks",method=RequestMethod.GET)
	public List<Book> recentBooks() throws NoBooksFoundException
	{
		return listBooks.recentBooks();
	}
	
	@RequestMapping(value="/bestSellingBooks",method=RequestMethod.GET)
	public List<Book> bestSellingBooks() throws NoBooksFoundException
	{
		return listBooks.bestSellingBooks();
	}
	
	@RequestMapping(value="/mostFavoredBooks",method=RequestMethod.GET)
	public List<Book> mostFavoredBooks() throws NoBooksFoundException
	{
		return listBooks.mostFavoredBooks();
	}
	
}
