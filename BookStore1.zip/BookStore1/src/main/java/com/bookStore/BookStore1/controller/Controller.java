package com.bookStore.BookStore1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.service.CategoryMgmt;

@RestController
public class Controller {
	
	@Autowired
	CategoryMgmt categoryMgmt;
	
	@RequestMapping(value="/createCategory",method=RequestMethod.PUT)
	public Category createCategory(@RequestBody Category category)
	{
		
		return categoryMgmt.createCategory(category);
	}
	
	@RequestMapping(value="/findAllCategory",method=RequestMethod.GET)
	public List<Category> findAllCategory()
	{
		return categoryMgmt.findAllCategory();
	}
	
	@RequestMapping(value="/deleteCategory",method=RequestMethod.DELETE)
	public Category deleteCategory(@RequestBody Category category)
	{
		return categoryMgmt.deletecategory(category);
	}
	
	@RequestMapping(value="/editCategory",method=RequestMethod.PUT)
	public Category editCategory(@RequestBody Category category)
	{
		return categoryMgmt.editCategory(category);
	}
}
