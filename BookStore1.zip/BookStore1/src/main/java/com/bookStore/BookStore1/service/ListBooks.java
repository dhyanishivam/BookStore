package com.bookStore.BookStore1.service;

import java.util.List;

import com.bookStore.BookStore1.beans.Book;

public interface ListBooks {
	
	public Book createBook(Book book);
	public List<Book> categoryBooks(String category);
	public List<Book> recentBooks();
	public List<Book> bestSellingBooks();
	public List<Book> mostFavoredBooks();
	public List<Book> showAllBooks();

}
