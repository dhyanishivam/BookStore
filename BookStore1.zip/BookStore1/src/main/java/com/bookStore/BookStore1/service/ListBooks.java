package com.bookStore.BookStore1.service;

import java.util.List;

import com.bookStore.BookStore1.beans.Book;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.NoBooksFoundException;

public interface ListBooks {
	
	public List<Book> categoryBooks(String category) throws CategoryDoesNotExistsException;
	public List<Book> recentBooks() throws NoBooksFoundException;
	public List<Book> bestSellingBooks() throws NoBooksFoundException;
	public List<Book> mostFavoredBooks() throws NoBooksFoundException;
	public List<Book> showAllBooks() throws NoBooksFoundException;

}
