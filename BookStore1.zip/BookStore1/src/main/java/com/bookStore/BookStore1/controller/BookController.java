package com.bookStore.BookStore1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bookStore.BookStore1.beans.Book;
import com.bookStore.BookStore1.service.ListBooks;

@RestController
public class BookController {
	
	@Autowired
	ListBooks listBooks;
	
	@RequestMapping(value="/addBook", method=RequestMethod.PUT)
	public Book addBook(@RequestBody Book book)
	{
		return listBooks.createBook(book);
	}
	
	@RequestMapping(value="/categoryBooks/{category}",method=RequestMethod.GET)
	public List<Book> categoryBooks(@PathVariable String category)
	{
		return listBooks.categoryBooks(category);
	}
	
	@RequestMapping(value="/showAllBooks",method=RequestMethod.GET)
	public List<Book> showAllBooks()
	{
		return listBooks.showAllBooks();
	}
	
	@RequestMapping(value="/recentBooks",method=RequestMethod.GET)
	public List<Book> recentBooks()
	{
		return listBooks.recentBooks();
	}
	
	@RequestMapping(value="/bestSellingBooks",method=RequestMethod.GET)
	public List<Book> bestSellingBooks()
	{
		return listBooks.bestSellingBooks();
	}
	
	@RequestMapping(value="/mostFavoredBooks",method=RequestMethod.GET)
	public List<Book> mostFavoredBooks()
	{
		return listBooks.mostFavoredBooks();
	}

}
