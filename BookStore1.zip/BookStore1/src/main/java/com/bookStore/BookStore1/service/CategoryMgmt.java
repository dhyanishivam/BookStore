package com.bookStore.BookStore1.service;

import java.util.List;
import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.CategoryIdAlreadyExistsException;

public interface CategoryMgmt {
	
	public List<Category> findAllCategory();
	public Category createCategory(Category category) throws CategoryIdAlreadyExistsException;
	public Category deletecategory(int categoryId) throws CategoryDoesNotExistsException;
	public Category editCategory(Category category) throws CategoryDoesNotExistsException;

}
