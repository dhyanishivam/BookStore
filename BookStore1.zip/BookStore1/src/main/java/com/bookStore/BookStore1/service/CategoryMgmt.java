package com.bookStore.BookStore1.service;

import java.util.List;
import com.bookStore.BookStore1.beans.Category;

public interface CategoryMgmt {
	
	public List<Category> findAllCategory();
	public Category createCategory(Category category);
	public Category deletecategory(Category category);
	public Category editCategory(Category category);

}
