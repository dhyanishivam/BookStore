package com.bookStore.BookStore1.service;

import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.bookStore.BookStore1.beans.Book;
import com.bookStore.BookStore1.repo.ListBooksRepo;


public class ListBooksImpl implements ListBooks {

	@Autowired
	ListBooksRepo listbooksrepo;
	
	@Override
	public List<Book> categoryBooks(String category) {
		List<Book> books = listbooksrepo.findAll();
		List<Book> catBooks = new LinkedList<>();
		for(Book book:books)
		{
			if( book.getCategory().getCategoryName().equals(category) )
			{
				catBooks.add(book);
			}
		}
		return catBooks;
	}

	@Override
	public List<Book> recentBooks() {
		List<Book> books = listbooksrepo.findAll();
		List<Book> recentBook = new LinkedList<>();
		List<Date> dates = new LinkedList<>();
		for(Book book:books)
		{
			dates.add(book.getPublishDate());
		}
		Collections.sort(dates);
		for(Date date:dates)
		{
			for(Book book:books)
			{
				if(date.compareTo(book.getPublishDate()) == 0)
				{
					recentBook.add(book);
				}
				
			}
		}
		return recentBook;
	}

	@Override
	public List<Book> bestSellingBooks() {
		List<Book> books = listbooksrepo.findAll();
		List<Book> bestSellingBook = new LinkedList<>();
		List<Integer> noOfCopies = new LinkedList<>();
		for(Book book:books)
		{
			noOfCopies.add(book.getCopiesSold());
		}
		Collections.sort(noOfCopies);
		for(Integer copies:noOfCopies)
		{
			for(Book book:books)
			{
				if(copies == book.getCopiesSold())
				{
					bestSellingBook.add(book);
				}
			}
		}
		return bestSellingBook;
	}

	@Override
	public List<Book> mostFavoredBooks() {
		List<Book> books = listbooksrepo.findAll();
		List<Book> mostFavoredBook = new LinkedList<>();
		List<Double> ratings = new LinkedList<>();
		for(Book book:books)
		{
			ratings.add(book.getRating());
		}
		Collections.sort(ratings);
		for(Double rating:ratings)
		{
			for(Book book:books)
			{
				if(rating.compareTo(book.getRating()) == 0)
				{
					mostFavoredBook.add(book);
				}
			}
		}
		return mostFavoredBook;
	}

}
