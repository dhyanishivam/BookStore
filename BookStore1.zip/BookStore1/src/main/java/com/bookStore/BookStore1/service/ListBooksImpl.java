package com.bookStore.BookStore1.service;

import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookStore.BookStore1.beans.Book;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.NoBooksFoundException;
import com.bookStore.BookStore1.repo.ListBooksRepo;

@Service
public class ListBooksImpl implements ListBooks {

	@Autowired
	ListBooksRepo listbooksrepo;
	
	
	@Override
	public List<Book> categoryBooks(String category) throws CategoryDoesNotExistsException {
		List<Book> books = listbooksrepo.findAll();
		List<Book> catBooks = new LinkedList<>();
		for(Book book:books)
		{
			if( book.getCategory().getCategoryName().equals(category) )
			{
				catBooks.add(book);
			}
		}
		if(catBooks.isEmpty())
		{
			throw new CategoryDoesNotExistsException("Category does not exists");
		}
		return catBooks;
		
	}

	@Override
	public List<Book> recentBooks() throws NoBooksFoundException {
		List<Book> books = listbooksrepo.findAll();
		List<Book> recentBook = new LinkedList<>();
		List<Date> dates = new LinkedList<>();
		for(Book book:books)
		{
			dates.add(book.getPublishedDate());
		}
		Collections.sort(dates);
		Collections.reverse(dates);
		for(Date date:dates)
		{
			for(Book book:books)
			{
				if(date.compareTo(book.getPublishedDate()) == 0)
				{
					recentBook.add(book);
				}
				
			}
		}
		if(recentBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return recentBook;
	}

	@Override
	public List<Book> bestSellingBooks() throws NoBooksFoundException {
		List<Book> books = listbooksrepo.findAll();
		List<Book> bestSellingBook = new LinkedList<>();
		List<Integer> noOfCopies = new LinkedList<>();
		for(Book book:books)
		{
			noOfCopies.add(book.getCopiesSold());
		}
		Collections.sort(noOfCopies);
		Collections.reverse(noOfCopies);
		for(Integer copies:noOfCopies)
		{
			for(Book book:books)
			{
				if(copies == book.getCopiesSold())
				{
					bestSellingBook.add(book);
				}
			}
		}
		if(bestSellingBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return bestSellingBook;
	}

	@Override
	public List<Book> mostFavoredBooks() throws NoBooksFoundException {
		List<Book> books = listbooksrepo.findAll();
		List<Book> mostFavoredBook = new LinkedList<>();
		List<Double> ratings = new LinkedList<>();
		for(Book book:books)
		{
			ratings.add(book.getRating());
		}
		Collections.sort(ratings);
		Collections.reverse(ratings);
		for(Double rating:ratings)
		{
			for(Book book:books)
			{
				if(rating.compareTo(book.getRating()) == 0)
				{
					mostFavoredBook.add(book);
				}
			}
		}
		if(mostFavoredBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return mostFavoredBook;
	}

	@Override
	public List<Book> showAllBooks() throws NoBooksFoundException {
		List<Book> allBooks =  listbooksrepo.findAll();
		if(allBooks.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return allBooks;
	}
	
	

}
