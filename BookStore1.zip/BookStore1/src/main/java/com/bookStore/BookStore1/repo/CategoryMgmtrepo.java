package com.bookStore.BookStore1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookStore.BookStore1.beans.Category;

public interface CategoryMgmtrepo extends JpaRepository<Category, Integer> {

}
