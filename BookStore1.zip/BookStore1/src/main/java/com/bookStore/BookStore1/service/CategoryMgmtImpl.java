package com.bookStore.BookStore1.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.exceptions.CategoryDoesNotExistsException;
import com.bookStore.BookStore1.exceptions.CategoryIdAlreadyExistsException;
import com.bookStore.BookStore1.repo.CategoryMgmtrepo;

@Service
public class CategoryMgmtImpl implements CategoryMgmt {

	@Autowired
	CategoryMgmtrepo categoryRepo;
	

	@Override
	public List<Category> findAllCategory() {
		return categoryRepo.findAll();
	}

	@Override
	public Category createCategory(Category category) throws CategoryIdAlreadyExistsException {
		List<Category> categories = categoryRepo.findAll();
		for (Category checkcategory:categories)
		{
			if(checkcategory.getCategoryName().equals(category.getCategoryName()))
			{
				throw new CategoryIdAlreadyExistsException("This Category Already Exists");
			}
		}
		return categoryRepo.saveAndFlush(category);
	}

	@Override
	public Category deletecategory(int categoryId) throws CategoryDoesNotExistsException {
		List<Category> categories = categoryRepo.findAll();
		for(Category checkcategory:categories)
		{
			if(checkcategory.getCategoryId() == categoryId)
			{
				categoryRepo.deleteById(categoryId);
				return null;
			}
		}
		throw new CategoryDoesNotExistsException("Category Id does not exists");
		
	}

	@Override
	public Category editCategory(Category category) throws CategoryDoesNotExistsException {
		List<Category> categories = categoryRepo.findAll();
		for(Category checkcategory:categories)
		{
			if(checkcategory.getCategoryId() == category.getCategoryId())
			{
				return categoryRepo.saveAndFlush(category);
			}
		}
		throw new CategoryDoesNotExistsException("Category Id does not exists");
		
	}

}
