package com.bookStore.BookStore1.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bookStore.BookStore1.beans.Category;
import com.bookStore.BookStore1.repo.CategoryMgmtrepo;

@Service
public class CategoryMgmtImpl implements CategoryMgmt {

	@Autowired
	CategoryMgmtrepo categoryRepo;
	

	@Override
	public List<Category> findAllCategory() {
		return categoryRepo.findAll();
	}

	@Override
	public Category createCategory(Category category) {
		return categoryRepo.saveAndFlush(category);
	}

	@Override
	public Category deletecategory(Category category) {
		categoryRepo.delete(category);
		return category;
		
	}

	@Override
	public Category editCategory(Category category) {
		return categoryRepo.saveAndFlush(category);
	}

}
